﻿using LegendsOfValor_TheGuildTrials.Core.Contracts;
using LegendsOfValor_TheGuildTrials.Models;
using LegendsOfValor_TheGuildTrials.Models.Contracts;
using LegendsOfValor_TheGuildTrials.Repositories;
using LegendsOfValor_TheGuildTrials.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LegendsOfValor_TheGuildTrials.Core
{
    public class Controller : IController
    {
        private HeroRepository _heroRepository;
        private GuildRepository _guildRepository;
        public Controller()
        {
            _heroRepository = new HeroRepository();
            _guildRepository = new GuildRepository();
        }

        public string AddHero(string heroTypeName, string heroName, string runeMark)
        {
            if (heroTypeName != "Warrior" && heroTypeName != "Sorcerer" && heroTypeName != "Spellblade") 
            {
                return string.Format(OutputMessages.InvalidHeroType, heroTypeName);
            }
            if (_heroRepository.GetModel(runeMark) != null)
            {
                return string.Format(OutputMessages.HeroAlreadyExists, runeMark);
                //return $"A hero bearing the RuneMark {runeMark} already walks among us.";
            }
            IHero hero;
            if (heroTypeName == "Warrior")
            {
                hero = new Warrior(heroName, runeMark);
            }
            else if (heroTypeName == "Sorcerer")
            {
                hero = new Sorcerer(heroName, runeMark);
            }
            else /*(heroTypeName == "Spellblade")*/
            {
                hero = new Spellblade(heroName, runeMark);
            }
            _heroRepository.AddModel(hero);
            return string.Format(OutputMessages.HeroAdded, heroTypeName, heroName, runeMark);
           // return $"{heroTypeName} {heroName} awakened with RuneMark {runeMark}.";
        }

        public string CreateGuild(string guildName)
        {
            if (_guildRepository.GetModel(guildName) != null)
            {
                return string.Format(OutputMessages.GuildAlreadyExists, guildName);
            }
            Guild guid = new Guild(guildName);

            _guildRepository.AddModel(guid);

            return string.Format(OutputMessages.GuildCreated, guildName);
        }

        public string RecruitHero(string runeMark, string guildName)
        {
            IHero hero = _heroRepository.GetModel(runeMark);
            IGuild guild = _guildRepository.GetModel(guildName);

            if (_heroRepository.GetModel(runeMark)==null)
            {
                return string.Format(OutputMessages.HeroNotFound, runeMark);
            }
            if (_guildRepository.GetModel(guildName)==null)
            {
                return string.Format(OutputMessages.GuildNotFound, guildName);
            }
            if (!string.IsNullOrEmpty(hero.GuildName))
            {
                return string.Format(OutputMessages.HeroAlreadyInGuild, guildName);
            }
            if (guild.IsFallen)
            {
                return string.Format(OutputMessages.GuildIsFallen, guildName);
            }
            if (guild.Wealth < 500)
            {
                return string.Format(OutputMessages.GuildCannotAffordRecruitment, guildName);
            }
            if ((hero is Warrior && guild.Name != "WarriorGuild" && guild.Name != "ShadowGuild") ||
                (hero is Sorcerer && guild.Name != "SorcererGuild" && guild.Name != "ShadowGuild") ||
                (hero is Spellblade && guild.Name != "WarriorGuild" && guild.Name != "SorcererGuild"))
            {
                return string.Format(OutputMessages.HeroTypeNotCompatible, hero.GetType().Name, guildName);
            }
            hero.JoinGuild(guild);
            guild.RecruitHero(hero);
            return string.Format(OutputMessages.HeroRecruited, hero.Name, guild.Name);
        }

        public string StartWar(string attackerGuildName, string defenderGuildName)
        {
            var attackerGuild = _guildRepository.GetModel(attackerGuildName);
            var defenderGuild = _guildRepository.GetModel(defenderGuildName);

            if (attackerGuild == null || defenderGuild == null)
            {
                return string.Format(OutputMessages.OneOfTheGuildsDoesNotExist);
            }
            if (attackerGuild.IsFallen||defenderGuild.IsFallen)
            {
                return string.Format(OutputMessages.OneOfTheGuildsIsFallen);
            }

            int attackerPower = 0;
            foreach (var runeMark in attackerGuild.Legion)
            {
                IHero hero = _heroRepository.GetModel(runeMark);
                if (hero!=null)
                {
                    attackerPower += hero.Power + hero.Mana + hero.Stamina;
                }
            }
            int deffenderPower = 0;
            foreach (var runeMark in defenderGuild.Legion)
            {
                IHero hero = _heroRepository.GetModel(runeMark);
                if (hero != null)
                {
                    deffenderPower += hero.Power + hero.Mana + hero.Stamina;
                }
            }

            IGuild winer;
            IGuild loser;

            if (attackerPower > deffenderPower)
            {
                winer = attackerGuild;
                loser = defenderGuild;
            }
            else
            {
                winer = defenderGuild;
                loser = attackerGuild;
            }
            double stolenGold = loser.Wealth;
            winer.WinWar(loser.Wealth);
            loser.LoseWar();

            if (winer==attackerGuild)
            {
                return string.Format(OutputMessages.WarWon, attackerGuild.Name, defenderGuild.Name, stolenGold);
            }
            else
            {
                return string.Format(OutputMessages.WarLost, defenderGuild.Name, stolenGold, attackerGuild.Name);
            }

        }
       

        public string TrainingDay(string guildName)
        {
            var guild = _guildRepository.GetModel(guildName);
            int goldNeeded = 200;
            if (guild==null)
            {
                return string.Format(OutputMessages.GuildNotFound, guildName);
            }
            if (guild.IsFallen)
            {
                return string.Format(OutputMessages.GuildTrainingDayIsFallen,guildName);
            }

            int totalTrainingCost = goldNeeded * guild.Legion.Count;
            if (guild.Wealth<totalTrainingCost)
            {
                return string.Format(OutputMessages.TrainingDayFailed, guildName);

            }
            List<IHero> heroesToTrain = new List<IHero>();
            foreach (var runeMark in guild.Legion)
            {
                IHero hero = _heroRepository.GetModel(runeMark);
                if (hero != null)
                {
                    heroesToTrain.Add(hero);
                }
            }
            guild.TrainLegion(heroesToTrain);
            return string.Format(OutputMessages.TrainingDayStarted, guildName, heroesToTrain.Count, totalTrainingCost);
        }


        public string ValorState()
        {
            var allGuilds = _guildRepository.GetAll()
                .OrderByDescending(g => g.Wealth)
                .ToList();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Valor State:");

            foreach (var guild in allGuilds)
            {
                sb.AppendLine($"{guild.Name} (Wealth: {guild.Wealth})");

                List<IHero> heroes = new List<IHero>();
                foreach (var runeMark in guild.Legion)
                {
                    IHero hero = _heroRepository.GetModel(runeMark);
                    if (hero != null)
                    {
                        heroes.Add(hero);
                    }
                }

                heroes.Sort((h1, h2) => string.Compare(h1.Name, h2.Name));

                foreach (var hero in heroes)
                {
                    sb.AppendLine($"-Hero: [{hero.Name}] of the Guild '{guild.Name}' - RuneMark: {hero.RuneMark}");
                    sb.AppendLine($"--Essence Revealed – Power [{hero.Power}] Mana [{hero.Mana}] Stamina [{hero.Stamina}]");
                }
            }

            return sb.ToString().TrimEnd();
        }

    }
}

