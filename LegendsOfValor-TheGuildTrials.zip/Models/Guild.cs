﻿using LegendsOfValor_TheGuildTrials.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LegendsOfValor_TheGuildTrials.Models
{
    public class Guild:IGuild
    {
		private string name;
		private double wealth;
        private readonly List<string> legion = new List<string>();
        public Guild(string name)
        {
			this.Name = name;
			this.Wealth = 5000;
			IsFallen = false;

        }

		public IReadOnlyCollection<string> Legion => legion.AsReadOnly();
		public bool IsFallen { get; private set; }
		public double Wealth
        {
			get => wealth;
			private set =>wealth=Math.Max(0,value);
			
		}

		public string Name
		{
			get => name;
			set 
			{
				if (value != "WarriorGuild" && value != "SorcererGuild" && value != "ShadowGuild") 
				{
					throw new ArgumentException("Unknown guilds hold no place in this realm.");
				}
				name = value;
			}
		}

		int IGuild.Wealth => (int)Wealth;

        public void RecruitHero(IHero hero)
		{
			double recrutmentCost = 500;
            if (IsFallen || Wealth < recrutmentCost)
                return;

			wealth -= recrutmentCost;

			legion.Add(hero.RuneMark);
            
        }
		public void TrainLegion(ICollection<IHero> heroesToTrain)
		{
			double traingCostPerHero = 200;
            if (IsFallen || heroesToTrain == null || heroesToTrain.Count == 0)
                return;
			foreach (var hero in heroesToTrain)
			{
				if (wealth<traingCostPerHero)
				{
					break;
				}
				wealth -= traingCostPerHero;
				hero.Train();
			}
        }
		public void WinWar(int goldAmount)
		{
			Wealth += goldAmount;
		}
		public  void LoseWar()
		{
			IsFallen = true;
			Wealth = 0;
		}


    }
}
