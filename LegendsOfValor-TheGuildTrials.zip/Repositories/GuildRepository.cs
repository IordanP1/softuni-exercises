﻿using LegendsOfValor_TheGuildTrials.Models.Contracts;
using LegendsOfValor_TheGuildTrials.Repositories.Contratcs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LegendsOfValor_TheGuildTrials.Repositories
{
    public class GuildRepository : IRepository<IGuild>
    {
        private readonly List<IGuild> guilds = new List<IGuild>();
        public void AddModel(IGuild entity)
        {
            if (entity!=null)
            {
                guilds.Add(entity);
            }
        }

        public IReadOnlyCollection<IGuild> GetAll()
        {
            return guilds.AsReadOnly();
        }

        public IGuild GetModel(string guildName)
        {
            foreach (var guild in guilds)
            {
                if (guild.Name==guildName)
                {
                    return guild;
                }
            }
            return null;
        }
    }
}
