﻿using LegendsOfValor_TheGuildTrials.Models.Contracts;
using LegendsOfValor_TheGuildTrials.Repositories.Contratcs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LegendsOfValor_TheGuildTrials.Repositories
{
    public class HeroRepository : IRepository<IHero>
    {
        private readonly List<IHero> heroes = new List<IHero>();
        public void AddModel(IHero entity)
        {
            if (entity !=null)
            {
                heroes.Add(entity);
            }
        }

        public IReadOnlyCollection<IHero> GetAll()
        {
            return heroes.AsReadOnly();
        }

        public IHero GetModel(string runeMarkOrGuildName)
        {
            foreach (var hero in heroes)
            {
                if (hero.RuneMark==runeMarkOrGuildName)
                {
                    return hero;
                }
            }
            return null;
        }
    }
}
